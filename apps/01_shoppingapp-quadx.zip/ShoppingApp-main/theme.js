export const COLORS = {
  plum: "#4B1B2F",
  ivory: "#FAF7F0",
  black: "#000000",
  gray: "#3B3B3B",
};
