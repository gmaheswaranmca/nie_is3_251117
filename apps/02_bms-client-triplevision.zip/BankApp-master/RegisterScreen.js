import React, { useState } from "react";
import { View, TextInput, Button, Text } from "react-native";
import { registerUser } from "./api";

export default function RegisterScreen() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [message, setMessage] = useState("");

  const handleRegister = async () => {
    try {
      const user = await registerUser(name, email, password);
      setMessage(`Registered successfully! ID: ${user.id}`);
    } catch (err) {
      setMessage(err.response?.data?.error || "Error registering");
    }
  };

  return (
    <View style={{ padding: 20 }}>
      <TextInput placeholder="Name" value={name} onChangeText={setName} />
      <TextInput placeholder="Email" value={email} onChangeText={setEmail} />
      <TextInput
        placeholder="Password"
        value={password}
        onChangeText={setPassword}
        secureTextEntry
      />
      <Button title="Register" onPress={handleRegister} />
      <Text>{message}</Text>
    </View>
  );
}
