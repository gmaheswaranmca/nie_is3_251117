import axios from "axios";

// Replace with your PC's local network IP, NOT localhost
// Example: 192.168.1.10 is your computer's IP in your Wi-Fi network
const API_BASE = "http://192.168.1.10:3000";

export const registerUser = async (name, email, password) => {
  try {
    const res = await axios.post(`${API_BASE}/users/register`, { name, email, password });
    return res.data;
  } catch (err) {
    console.log(err.response?.data || err.message);
    throw err;
  }
};

export const loginUser = async (email, password) => {
  try {
    const res = await axios.post(`${API_BASE}/users/login`, { email, password });
    return res.data;
  } catch (err) {
    console.log(err.response?.data || err.message);
    throw err;
  }
};
