import React, { createContext, useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export const AppContext = createContext();

export const AppProvider = ({ children }) => {
  const [users, setUsers] = useState([]);
  const [currentUser, setCurrentUser] = useState(null);
  const [accounts, setAccounts] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [loans, setLoans] = useState([]);

  // ----------------------------------
  // 🔄 Load Saved Data on App Start
  // ----------------------------------
  useEffect(() => {
    const loadData = async () => {
      const savedUsers = await AsyncStorage.getItem("users");
      const savedCurrent = await AsyncStorage.getItem("currentUser");
      const savedAcc = await AsyncStorage.getItem("accounts");
      const savedTx = await AsyncStorage.getItem("transactions");
      const savedLoans = await AsyncStorage.getItem("loans");

      if (savedUsers) setUsers(JSON.parse(savedUsers));
      if (savedCurrent) setCurrentUser(JSON.parse(savedCurrent));
      if (savedAcc) setAccounts(JSON.parse(savedAcc));
      if (savedTx) setTransactions(JSON.parse(savedTx));
      if (savedLoans) setLoans(JSON.parse(savedLoans));
    };

    loadData();
  }, []);

  // ----------------------------------
  // 💾 Save Data When Updated
  // ----------------------------------
  useEffect(() => {
    AsyncStorage.setItem("users", JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    if (currentUser)
      AsyncStorage.setItem("currentUser", JSON.stringify(currentUser));
    else AsyncStorage.removeItem("currentUser");
  }, [currentUser]);

  useEffect(() => {
    AsyncStorage.setItem("accounts", JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    AsyncStorage.setItem("transactions", JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    AsyncStorage.setItem("loans", JSON.stringify(loans));
  }, [loans]);

  // ----------------------------------
  // 📝 Format Amount to ₹
  // ----------------------------------
  const formatRupees = (amount) =>
    "₹" + amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");

  // ----------------------------------
  // 🆕 Register
  // ----------------------------------
  const registerUser = (name, email, password) => {
    const normalizedEmail = email.toLowerCase().trim();
    if (users.find(u => u.email === normalizedEmail)) return false;
    const newUser = { name, email: normalizedEmail, password };
    setUsers(prev => [...prev, newUser]);
    setCurrentUser(newUser);
    return true;
  };

  // ----------------------------------
  // 🔐 Login
  // ----------------------------------
  const loginUser = (email, password) => {
    const normalizedEmail = email.toLowerCase().trim();
    const user = users.find(
      u => u.email === normalizedEmail && u.password === password
    );
    if (!user) return false;
    setCurrentUser(user);
    return true;
  };

  // ----------------------------------
  // ⚙️ Update Profile
  // ----------------------------------
  const updateUser = (updatedUser) => {
    if (!currentUser) return false;
    setCurrentUser(updatedUser);
    setUsers(prev =>
      prev.map(u => (u.email === currentUser.email ? updatedUser : u))
    );
    return true;
  };

  // ----------------------------------
  // 💳 Add Account
  // ----------------------------------
  const addAccount = (type, balance) => {
    const newAcc = { id: Date.now(), type, balance };
    setAccounts(prev => [...prev, newAcc]);
    return newAcc;
  };

  // ----------------------------------
  // 💸 Transfer Money
  // ----------------------------------
  const transferAmount = (fromId, toId, amount) => {
    setAccounts(prev => {
      const fromAcc = prev.find(a => a.id === fromId);
      const toAcc = prev.find(a => a.id === toId);
      if (!fromAcc || !toAcc || fromAcc.balance < amount) return prev;

      const updated = prev.map(acc => {
        if (acc.id === fromId) return { ...acc, balance: acc.balance - amount };
        if (acc.id === toId) return { ...acc, balance: acc.balance + amount };
        return acc;
      });

      setTransactions(tx => [
        ...tx,
        {
          id: Date.now(),
          from: fromAcc.id,
          to: toAcc.id,
          amount,
          date: new Date().toLocaleString()
        },
      ]);

      return updated;
    });
    return true;
  };

  // ----------------------------------
  // 🏦 Request Loan
  // ----------------------------------
  const requestLoan = (accountId, amount, reason) => {
    const acc = accounts.find(a => a.id === accountId);
    if (!acc) return false;
    const loan = {
      id: Date.now(),
      accountId,
      amount,
      reason,
      status: "Pending",
      date: new Date().toLocaleString()
    };
    setLoans(prev => [...prev, loan]);
    return true;
  };

  // ----------------------------------
  // 🚪 Logout
  // ----------------------------------
  const logoutUser = () => {
    setCurrentUser(null);
  };

  return (
    <AppContext.Provider
      value={{
        users,
        currentUser,
        accounts,
        transactions,
        loans,
        registerUser,
        loginUser,
        addAccount,
        transferAmount,
        requestLoan,
        updateUser,
        logoutUser,
        formatRupees
      }}
    >
      {children}
    </AppContext.Provider>
  );
};
