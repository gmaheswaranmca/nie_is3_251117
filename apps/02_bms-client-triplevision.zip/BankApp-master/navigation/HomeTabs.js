import React from "react";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import HomeScreen from "../screens/HomeScreen";
import DashboardScreen from "../screens/DashboardScreen";
import AddAccountScreen from "../screens/AddAccountScreen";
import AccountListScreen from "../screens/AccountListScreen";
import TransferScreen from "../screens/TransferScreen";
import LoanScreen from "../screens/LoanScreen";
import PassbookScreen from "../screens/PassbookScreen";
import ReportScreen from "../screens/ReportScreen";
import ProfileScreen from "../screens/ProfileScreen";
import SettingScreen from "../screens/SettingScreen";

import { Ionicons } from "@expo/vector-icons";

const Tab = createBottomTabNavigator();

export default function HomeTabs() {
  return (
    <Tab.Navigator screenOptions={{ headerShown: false }}>
      <Tab.Screen name="Home" component={HomeScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="home" color={color} size={size} />
      }} />
      <Tab.Screen name="Dashboard" component={DashboardScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="speedometer" color={color} size={size} />
      }} />
      <Tab.Screen name="AddAccount" component={AddAccountScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="add-circle" color={color} size={size} />
      }} />
      <Tab.Screen name="Accounts" component={AccountListScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="list" color={color} size={size} />
      }} />
      <Tab.Screen name="Transfer" component={TransferScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="swap-horizontal" color={color} size={size} />
      }} />
      <Tab.Screen name="Loan" component={LoanScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="cash" color={color} size={size} />
      }} />
      <Tab.Screen name="Passbook" component={PassbookScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="book" color={color} size={size} />
      }} />
      <Tab.Screen name="Report" component={ReportScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="stats-chart" color={color} size={size} />
      }} />
      <Tab.Screen name="Profile" component={ProfileScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="person" color={color} size={size} />
      }} />
      <Tab.Screen name="Settings" component={SettingScreen} options={{
        tabBarIcon: ({ color, size }) => <Ionicons name="settings" color={color} size={size} />
      }} />
    </Tab.Navigator>
  );
}
