import React, { useContext } from "react";
import { View, Text, FlatList, StyleSheet } from "react-native";
import { AppContext } from "../context/AppContext";

export default function AccountListScreen() {
  const { accounts, formatRupees } = useContext(AppContext);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>All Accounts</Text>
      <FlatList
        data={accounts}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text style={styles.type}>{item.type} Account</Text>
            <Text style={styles.balance}>{formatRupees(item.balance)}</Text>
          </View>
        )}
        ListEmptyComponent={<Text>No accounts available</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 15 },
  item: { flexDirection: "row", justifyContent: "space-between", padding: 12, borderBottomWidth: 1 },
  type: { fontSize: 16 },
  balance: { fontSize: 16, fontWeight: "bold" },
});
