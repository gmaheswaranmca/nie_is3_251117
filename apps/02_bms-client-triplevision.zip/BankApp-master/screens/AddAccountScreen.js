import React, { useState, useContext } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";
import { AppContext } from "../context/AppContext";
import { Picker } from '@react-native-picker/picker'; // ✅ Correct Picker import

export default function AddAccountScreen() {
  const { addAccount } = useContext(AppContext);
  const [type, setType] = useState("Personal");
  const [balance, setBalance] = useState("");

  const handleAdd = () => {
    if (!balance) {
      Alert.alert("Error", "Please enter balance");
      return;
    }
    addAccount(type, Number(balance));
    Alert.alert("Success", "Account added successfully");
    setBalance("");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Add Account</Text>
      <Text>Account Type:</Text>
      <Picker selectedValue={type} onValueChange={setType}>
        <Picker.Item label="Personal" value="Personal" />
        <Picker.Item label="Business" value="Business" />
        <Picker.Item label="Education" value="Education" />
        <Picker.Item label="Home" value="Home" />
      </Picker>
      <TextInput
        placeholder="Initial Balance"
        value={balance}
        onChangeText={setBalance}
        keyboardType="numeric"
        style={styles.input}
      />
      <Button title="Add Account" onPress={handleAdd} />
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:20},
  title:{fontSize:22,fontWeight:"bold",marginBottom:10},
  input:{borderWidth:1,padding:10,marginBottom:15,borderRadius:5}
});
