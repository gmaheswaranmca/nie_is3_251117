import React, { useContext } from "react";
import { View, Text, StyleSheet, FlatList } from "react-native";
import { AppContext } from "../context/AppContext";

export default function DashboardScreen() {
  const { accounts, formatRupees } = useContext(AppContext);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Accounts Overview</Text>
      <FlatList
        data={accounts}
        keyExtractor={item => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.accountItem}>
            <Text style={styles.type}>{item.type}</Text>
            <Text style={styles.balance}>{formatRupees(item.balance)}</Text>
          </View>
        )}
        ListEmptyComponent={<Text>No accounts found</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 15 },
  accountItem: { flexDirection: "row", justifyContent: "space-between", padding: 10, borderBottomWidth: 1 },
  type: { fontSize: 16 },
  balance: { fontSize: 16, fontWeight: "bold" },
});
