import React, { useContext } from "react";
import { View, Text, StyleSheet, Button } from "react-native";
import { AppContext } from "../context/AppContext";

export default function HomeScreen({ navigation }) {
  const { currentUser, accounts, formatRupees } = useContext(AppContext);

  const totalBalance = accounts.reduce((acc, a) => acc + a.balance, 0);

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Welcome, {currentUser?.name}</Text>
      <Text style={styles.balance}>Total Balance: {formatRupees(totalBalance)}</Text>
      <Button title="Go to Dashboard" onPress={() => navigation.navigate("Dashboard")} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", alignItems: "center", padding: 20 },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 20 },
  balance: { fontSize: 18, marginBottom: 20 },
});
