import React, { useState, useContext } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";
import { AppContext } from "../context/AppContext";
import { Picker } from "@react-native-picker/picker"; // ✅ Updated import

export default function LoanScreen() {
  const { accounts, requestLoan, formatRupees } = useContext(AppContext);
  const [accountId, setAccountId] = useState("");
  const [amount, setAmount] = useState("");
  const [reason, setReason] = useState("");

  const handleLoanRequest = () => {
    if (!accountId || !amount || !reason) {
      Alert.alert("Error", "Please fill all fields");
      return;
    }
    const success = requestLoan(Number(accountId), Number(amount), reason);
    if (success) {
      Alert.alert("Success", "Loan requested successfully");
      setAmount(""); setReason("");
    } else {
      Alert.alert("Error", "Failed to request loan");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Request Loan</Text>

      <Text>Select Account:</Text>
      <Picker selectedValue={accountId} onValueChange={setAccountId} style={styles.picker}>
        <Picker.Item label="Select Account" value="" />
        {accounts.map(acc => (
          <Picker.Item key={acc.id} label={`${acc.type} - ${formatRupees(acc.balance)}`} value={acc.id.toString()} />
        ))}
      </Picker>

      <TextInput
        placeholder="Loan Amount"
        value={amount}
        onChangeText={setAmount}
        keyboardType="numeric"
        style={styles.input}
      />
      <TextInput
        placeholder="Reason for Loan"
        value={reason}
        onChangeText={setReason}
        style={styles.input}
      />

      <Button title="Request Loan" onPress={handleLoanRequest} />
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:20},
  title:{fontSize:22,fontWeight:"bold",marginBottom:15},
  picker:{marginVertical:10},
  input:{borderWidth:1,padding:10,marginVertical:10,borderRadius:5}
});
