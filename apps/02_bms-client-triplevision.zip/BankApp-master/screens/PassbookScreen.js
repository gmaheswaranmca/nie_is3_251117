import React, { useContext } from "react";
import { View, Text, FlatList, StyleSheet } from "react-native";
import { AppContext } from "../context/AppContext";

export default function PassbookScreen() {
  const { transactions, accounts, formatRupees } = useContext(AppContext);

  const getAccountType = (id) => accounts.find(a => a.id === id)?.type || "Unknown";

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Passbook</Text>
      <FlatList
        data={transactions}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={styles.item}>
            <Text>From: {getAccountType(item.from)}</Text>
            <Text>To: {getAccountType(item.to)}</Text>
            <Text>Amount: {formatRupees(item.amount)}</Text>
            <Text>Date: {item.date}</Text>
          </View>
        )}
        ListEmptyComponent={<Text>No transactions yet</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:20},
  title:{fontSize:22,fontWeight:"bold",marginBottom:15},
  item:{borderWidth:1,padding:10,marginBottom:10,borderRadius:5}
});
