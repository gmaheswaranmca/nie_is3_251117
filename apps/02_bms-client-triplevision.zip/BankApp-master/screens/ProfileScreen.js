import React, { useContext } from "react";
import { View, Text, Button, StyleSheet } from "react-native";
import { AppContext } from "../context/AppContext";

export default function ProfileScreen({ navigation }) {
  const { currentUser, setCurrentUser } = useContext(AppContext);

  const handleLogout = () => {
    setCurrentUser(null);
    navigation.replace("Login");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile</Text>
      <Text>Name: {currentUser?.name}</Text>
      <Text>Email: {currentUser?.email}</Text>
      <Button title="Logout" onPress={handleLogout} />
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,justifyContent:"center",alignItems:"center",padding:20},
  title:{fontSize:22,fontWeight:"bold",marginBottom:15}
});
