import React, { useContext, useState, useEffect } from "react";
import { View, Text, TextInput, Button, StyleSheet, Alert } from "react-native";
import { AppContext } from "../context/AppContext";

export default function SettingScreen({ navigation }) {
  const { currentUser, setCurrentUser, users, setUsers } = useContext(AppContext);

  // Local state for editing
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");

  // Initialize local state when currentUser changes
  useEffect(() => {
    if (currentUser) {
      setName(currentUser.name || "");
      setEmail(currentUser.email || "");
    } else {
      setName("");
      setEmail("");
    }
  }, [currentUser]);

  // Update user details
  const handleUpdate = () => {
    if (!currentUser) {
      Alert.alert("Error", "No user logged in");
      return;
    }

    if (!name || !email) {
      Alert.alert("Error", "Name and Email cannot be empty");
      return;
    }

    // Check if email already exists for another user
    const emailTaken = users.find(
      (u) => u.email === email && u.email !== currentUser.email
    );
    if (emailTaken) {
      Alert.alert("Error", "Email already registered");
      return;
    }

    // Update currentUser and users array
    const updatedUser = { ...currentUser, name, email };
    setCurrentUser(updatedUser);

    const updatedUsers = users.map((u) =>
      u.email === currentUser.email ? updatedUser : u
    );
    setUsers(updatedUsers);

    Alert.alert("Success", "Profile updated successfully");
  };

  // Logout function
  const handleLogout = () => {
    if (!currentUser) {
      Alert.alert("Error", "No user logged in");
      return;
    }

    Alert.alert(
      "Confirm Logout",
      "Are you sure you want to log out?",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Logout",
          style: "destructive",
          onPress: () => setCurrentUser(null),
        },
      ]
    );
  };

  // If no user is logged in, show message
  if (!currentUser) {
    return (
      <View style={styles.noUserContainer}>
        <Text style={styles.noUserText}>No user logged in</Text>
        <Button title="Go to Login" onPress={() => navigation.replace("Login")} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Settings</Text>

      <View style={styles.section}>
        <Text style={styles.label}>Name:</Text>
        <TextInput style={styles.input} value={name} onChangeText={setName} />
      </View>

      <View style={styles.section}>
        <Text style={styles.label}>Email:</Text>
        <TextInput
          style={styles.input}
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />
      </View>

      <View style={styles.section}>
        <Button title="Update Profile" onPress={handleUpdate} />
      </View>

      <View style={styles.section}>
        <Button title="Logout" color="#d9534f" onPress={handleLogout} />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: "#f9f9f9" },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20 },
  section: { marginBottom: 20 },
  label: { fontSize: 16, fontWeight: "600" },
  input: { borderWidth: 1, borderColor: "#ccc", padding: 10, borderRadius: 5, marginTop: 5 },
  noUserContainer: { flex: 1, justifyContent: "center", alignItems: "center", padding: 20 },
  noUserText: { fontSize: 18, marginBottom: 15 },
});
