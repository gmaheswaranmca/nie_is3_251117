import React, { useState, useContext } from "react";
import { View, TextInput, Button, Alert, StyleSheet, Text } from "react-native";
import { AppContext } from "../context/AppContext";

export default function SignupScreen({ navigation }) {
  const { registerUser } = useContext(AppContext);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const handleSignup = () => {
    if (!name || !email || !password) {
      Alert.alert("Error", "Please fill all fields");
      return;
    }
    const success = registerUser(name, email, password);
    if (success) {
      navigation.replace("HomeTabs");
    } else {
      Alert.alert("Error", "Email already registered");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Bank App Sign Up</Text>
      <TextInput placeholder="Full Name" value={name} onChangeText={setName} style={styles.input} />
      <TextInput placeholder="Email" value={email} onChangeText={setEmail} style={styles.input} keyboardType="email-address" />
      <TextInput placeholder="Password" value={password} onChangeText={setPassword} style={styles.input} secureTextEntry />
      <Button title="Sign Up" onPress={handleSignup} />
      <Text style={styles.link} onPress={() => navigation.navigate("Login")}>
        Already have an account? Login
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: "center", padding: 20 },
  title: { fontSize: 24, fontWeight: "bold", marginBottom: 20, textAlign: "center" },
  input: { borderWidth: 1, padding: 10, marginBottom: 15, borderRadius: 5 },
  link: { color: "blue", marginTop: 15, textAlign: "center" },
});
