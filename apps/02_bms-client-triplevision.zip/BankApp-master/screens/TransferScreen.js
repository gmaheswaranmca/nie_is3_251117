import React, { useState, useContext } from "react";
import { View, Text, TextInput, Button, Alert, StyleSheet } from "react-native";
import { AppContext } from "../context/AppContext";
import { Picker } from "@react-native-picker/picker"; // ✅ Updated import

export default function TransferScreen() {
  const { accounts, transferAmount, formatRupees } = useContext(AppContext);
  const [fromId, setFromId] = useState("");
  const [toId, setToId] = useState("");
  const [amount, setAmount] = useState("");

  const handleTransfer = () => {
    if (!fromId || !toId || !amount) {
      Alert.alert("Error", "Please select accounts and enter amount");
      return;
    }
    if (fromId === toId) {
      Alert.alert("Error", "Cannot transfer to same account");
      return;
    }
    const success = transferAmount(Number(fromId), Number(toId), Number(amount));
    if (success) {
      Alert.alert("Success", "Amount transferred successfully");
      setAmount("");
    } else {
      Alert.alert("Error", "Transfer failed. Check balance.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Transfer Money</Text>

      <Text>From Account:</Text>
      <Picker selectedValue={fromId} onValueChange={setFromId} style={styles.picker}>
        <Picker.Item label="Select Account" value="" />
        {accounts.map(acc => (
          <Picker.Item key={acc.id} label={`${acc.type} - ${formatRupees(acc.balance)}`} value={acc.id.toString()} />
        ))}
      </Picker>

      <Text>To Account:</Text>
      <Picker selectedValue={toId} onValueChange={setToId} style={styles.picker}>
        <Picker.Item label="Select Account" value="" />
        {accounts.map(acc => (
          <Picker.Item key={acc.id} label={`${acc.type} - ${formatRupees(acc.balance)}`} value={acc.id.toString()} />
        ))}
      </Picker>

      <TextInput
        placeholder="Amount"
        value={amount}
        onChangeText={setAmount}
        keyboardType="numeric"
        style={styles.input}
      />

      <Button title="Transfer" onPress={handleTransfer} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: { fontSize: 22, fontWeight: "bold", marginBottom: 15 },
  picker: { marginVertical: 10 },
  input: { borderWidth: 1, padding: 10, marginVertical: 10, borderRadius: 5 },
});
