export const formatRupees = (amount) => {
  if (!amount) return "₹0";
  return "₹" + amount.toLocaleString("en-IN");
};
