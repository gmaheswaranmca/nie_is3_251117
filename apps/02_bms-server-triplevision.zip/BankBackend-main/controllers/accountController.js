// BankBackend/controllers/accountController.js
import  Account  from "../models/Account.js";

export const createAccount = async (req, res) => {
  try {
    const { type, balance, userId } = req.body;
    const acc = await Account.create({ type, balance, UserId: userId });
    res.json(acc);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getAccountsByUser = async (req, res) => {
  const accounts = await Account.findAll({ where: { UserId: req.params.userId } });
  res.json(accounts);
};
