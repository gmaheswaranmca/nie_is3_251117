// BankBackend/controllers/loanController.js
import  Loan  from "../models/Loan.js";

export const requestLoan = async (req, res) => {
  const { accountId, amount, reason } = req.body;
  const loan = await Loan.create({ AccountId: accountId, amount, reason });
  res.json(loan);
};

export const getLoansByAccount = async (req, res) => {
  const loans = await Loan.findAll({ where: { AccountId: req.params.accountId } });
  res.json(loans);
};
