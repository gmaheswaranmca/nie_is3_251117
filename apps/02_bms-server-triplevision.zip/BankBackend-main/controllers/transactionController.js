// BankBackend/controllers/transactionController.js
import  Account  from "../models/Account.js";
import  Transaction  from "../models/Transaction.js";

export const transferAmount = async (req, res) => {
  try {
    const { fromId, toId, amount } = req.body;

    const fromAcc = await Account.findByPk(fromId);
    const toAcc = await Account.findByPk(toId);
    if (!fromAcc || !toAcc) return res.status(400).json({ error: "Invalid accounts" });
    if (fromAcc.balance < amount) return res.status(400).json({ error: "Insufficient balance" });

    fromAcc.balance -= amount;
    toAcc.balance += amount;
    await fromAcc.save();
    await toAcc.save();

    const tx = await Transaction.create({ fromId, toId, amount });
    res.json(tx);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getTransactionsByAccount = async (req, res) => {
  const txs = await Transaction.findAll({ where: { fromId: req.params.accountId } });
  res.json(txs);
};
