import express from "express";
import cors from "cors";
import { sequelize } from "./config/database.js";

// Import routes
import authRoutes from "./routes/auth.js";
import accountRoutes from "./routes/accounts.js";
import transferRoutes from "./routes/transfer.js";
import loanRoutes from "./routes/loans.js";
import transactionRoutes from "./routes/transactions.js";

const app = express();
app.use(cors());
app.use(express.json());

// Health check
app.get("/", (req, res) => res.json({ ok: true, service: "Bank API" }));

// Routes
app.use("/users", authRoutes);
app.use("/accounts", accountRoutes);
app.use("/transfer", transferRoutes);
app.use("/loans", loanRoutes);
app.use("/transactions", transactionRoutes);

// Sync DB and start server
const startServer = async () => {
  try {
    await sequelize.authenticate();
    await sequelize.sync({ alter: true });
    console.log("Database synced");

    const PORT = process.env.PORT || 3000;
    app.listen(PORT, () => console.log(`Bank API running on http://localhost:${PORT}`));
  } catch (err) {
    console.error("Unable to connect to DB:", err);
  }
};

startServer();
