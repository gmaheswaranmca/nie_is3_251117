import { DataTypes } from "sequelize";
import { sequelize } from "../config/database.js";
import { User } from "./User.js";

export const Account = sequelize.define("Account", {
  type: { type: DataTypes.STRING, allowNull: false },
  balance: { type: DataTypes.FLOAT, defaultValue: 0 },
});

// Relationship
Account.belongsTo(User);
User.hasMany(Account);
