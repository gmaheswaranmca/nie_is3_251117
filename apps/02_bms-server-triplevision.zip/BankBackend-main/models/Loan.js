import { DataTypes } from "sequelize";
import { sequelize } from "../config/database.js";
import { Account } from "./Account.js";

export const Loan = sequelize.define("Loan", {
  amount: { type: DataTypes.FLOAT, allowNull: false },
  reason: { type: DataTypes.STRING, allowNull: false },
});

// Relationship
Loan.belongsTo(Account);
Account.hasMany(Loan);
