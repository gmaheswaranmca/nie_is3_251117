import express from "express";
import { Account } from "../models/Account.js";

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const { type, balance, userId } = req.body;
    const acc = await Account.create({ type, balance, UserId: userId });
    res.json(acc);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/:userId", async (req, res) => {
  const accounts = await Account.findAll({ where: { UserId: req.params.userId } });
  res.json(accounts);
});

export default router;
