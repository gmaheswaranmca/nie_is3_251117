import express from "express";
import { Loan } from "../models/Loan.js";

const router = express.Router();

router.post("/", async (req, res) => {
  try {
    const { accountId, amount, reason } = req.body;
    const loan = await Loan.create({ AccountId: accountId, amount, reason });
    res.json(loan);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get("/:accountId", async (req, res) => {
  try {
    const loans = await Loan.findAll({ where: { AccountId: req.params.accountId } });
    res.json(loans);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
