import express from "express";
import { Transaction } from "../models/Transaction.js";

const router = express.Router();

router.get("/:accountId", async (req, res) => {
  try {
    const txs = await Transaction.findAll({ where: { fromId: req.params.accountId } });
    res.json(txs);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
