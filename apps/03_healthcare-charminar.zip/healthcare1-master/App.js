// App.js
import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { API_URL } from './src/config';

// Import Screens
import LoginScreen from './src/screens/LoginScreen';
import ReceptionistHome from './src/screens/ReceptionistHome';
import ViewPatientsScreen from './src/screens/ViewPatientScreen'; 
import PatientDetailScreen from './src/screens/PatientDetailScreen';
import AddPatientScreen from './src/screens/AddPatientScreen';
import AppointmentsScreen from './src/screens/AppointmentScreen';
import BillingScreen from './src/screens/BillingScreen.js';


import { initialPatients, initialAppointments, DOCTORS, TEST_COSTS } from './src/utility/Constant'; 
 

const Stack = createStackNavigator();

const App = () => {
  // State for authentication and data
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentUser, setCurrentUser] = useState(''); // <--- NEW: State to store the username
  
  const [patients, setPatients] = useState(initialPatients);
  const [appointments, setAppointments] = useState(initialAppointments);

  // --- Authentication Handlers ---
  // <--- CHANGED: Updated to accept usernameInput from LoginScreen
  const handleLogin = (usernameInput) => {
    setCurrentUser(usernameInput); 
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setCurrentUser(''); // Clear name on logout
  };

  // --- Data Handlers ---
  const addPatient = (newPatient) => {
    const newId = (patients.length + 1).toString();
    setPatients(prevPatients => [...prevPatients, { ...newPatient, id: newId }]);
  };
  
  const updatePatient = (updatedPatient) => {
    setPatients(prevPatients => 
      prevPatients.map(p => p.id === updatedPatient.id ? updatedPatient : p)
    );
  };

  const addAppointment = (newAppt) => {
    const doctorAppointments = appointments.filter(a => a.doctor === newAppt.doctor && a.date === newAppt.date).length;
    
    if (doctorAppointments >= 50) {
      return { success: false, message: 'Appointment limit (50) reached for this doctor on this date.' };
    }

    setAppointments(prevAppts => [...prevAppts, { ...newAppt, id: Date.now().toString() }]);
    return { success: true, message: 'Appointment booked successfully.' };
  };

  return (
    <NavigationContainer>
      <Stack.Navigator screenOptions={{ headerShown: false }}>
        {isAuthenticated ? (
          // Authenticated Stack
          <>
            <Stack.Screen name="Home" options={{ headerShown: false }}>
              {/* <--- CHANGED: Passing 'currentUser' instead of "Priya Singh" */}
              {props => <ReceptionistHome {...props} onLogout={handleLogout} receptionistName={currentUser} />}
            </Stack.Screen>
            <Stack.Screen name="ViewPatients" options={{ title: 'Patient List', headerShown: true }}>
              {props => <ViewPatientsScreen {...props} patients={patients} />}
            </Stack.Screen>
            
            <Stack.Screen name="PatientDetail" options={{ title: 'Patient Record', headerShown: true }}>
              {props => <PatientDetailScreen {...props} patients={patients} updatePatient={updatePatient} allTests={TEST_COSTS} />}
            </Stack.Screen>
            
            <Stack.Screen name="AddPatient" options={{ title: 'Add New Patient', headerShown: true }}>
              {props => <AddPatientScreen {...props} addPatient={addPatient} doctorList={DOCTORS} />}
            </Stack.Screen>
            <Stack.Screen name="Appointments" options={{ title: 'Booked Appointments', headerShown: true }}>
              {props => <AppointmentsScreen {...props} appointments={appointments} patients={patients} doctorList={DOCTORS} addAppointment={addAppointment} />}
            </Stack.Screen>
            <Stack.Screen name="Billing" options={{ title: 'Billing Counter', headerShown: true }}>
              {props => <BillingScreen {...props} patients={patients} />}
            </Stack.Screen>
          </>
        ) : (
          // Login Stack
          <Stack.Screen name="Login" options={{ title: 'Login' }}>
            {props => <LoginScreen {...props} onLogin={handleLogin} />}
          </Stack.Screen>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
};

export default App;