Android development using react native for Health Management System
