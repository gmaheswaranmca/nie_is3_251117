const API_URL = 'http://192.168.56.1:3000';

export {API_URL};