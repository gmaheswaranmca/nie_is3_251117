// src/screens/AddPatientScreen.js
import React, { useState } from 'react';
import { View, Text, TextInput, StyleSheet, ScrollView, TouchableOpacity, Switch, Alert } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import Icon from 'react-native-vector-icons/FontAwesome5';

const AddPatientScreen = ({ navigation, addPatient, doctorList }) => {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [disease, setDisease] = useState('');
  const [phone, setPhone] = useState('');
  
  // Admission State
  const [isAdmitted, setIsAdmitted] = useState(false);
  const [selectedDoctor, setSelectedDoctor] = useState(doctorList[0]);

  const handleSave = () => {
    // Basic Validation
    if (!name || !age || !disease || !phone) {
      Alert.alert('Error', 'Please fill in all required fields.');
      return;
    }

    const newPatient = {
      name,
      age: parseInt(age),
      disease,
      phoneNumber: phone,
      // If admitted, set date to today, otherwise null
      admittedDate: isAdmitted ? new Date().toISOString().split('T')[0] : null, 
      handlingDoctor: isAdmitted ? selectedDoctor : null,
      dischargedDate: null,
      tests: [],
      medications: [],
      doctorVisits: isAdmitted ? 1 : 0, // Initial visit if admitted
    };

    addPatient(newPatient);
    Alert.alert('Success', 'Patient registered successfully!', [
      { text: 'OK', onPress: () => navigation.goBack() }
    ]);
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.formCard}>
        <Text style={styles.header}>Patient Registration</Text>

        {/* Name */}
        <View style={styles.inputGroup}>
          <Icon name="user" size={18} color="#555" style={styles.icon} />
          <TextInput 
            style={styles.input} 
            placeholder="Full Name" 
            value={name} 
            onChangeText={setName} 
          />
        </View>

        {/* Age */}
        <View style={styles.inputGroup}>
          <Icon name="birthday-cake" size={18} color="#555" style={styles.icon} />
          <TextInput 
            style={styles.input} 
            placeholder="Age" 
            keyboardType="numeric"
            value={age} 
            onChangeText={setAge} 
          />
        </View>

        {/* Disease */}
        <View style={styles.inputGroup}>
          <Icon name="notes-medical" size={18} color="#555" style={styles.icon} />
          <TextInput 
            style={styles.input} 
            placeholder="Disease / Symptoms" 
            value={disease} 
            onChangeText={setDisease} 
          />
        </View>

        {/* Phone */}
        <View style={styles.inputGroup}>
          <Icon name="phone" size={18} color="#555" style={styles.icon} />
          <TextInput 
            style={styles.input} 
            placeholder="Phone Number" 
            keyboardType="phone-pad"
            value={phone} 
            onChangeText={setPhone} 
          />
        </View>

        {/* Admission Switch */}
        <View style={styles.switchContainer}>
          <Text style={styles.switchLabel}>Admit Patient Immediately?</Text>
          <Switch
            trackColor={{ false: "#767577", true: "#81b0ff" }}
            thumbColor={isAdmitted ? "#007bff" : "#f4f3f4"}
            onValueChange={setIsAdmitted}
            value={isAdmitted}
          />
        </View>

        {/* Doctor Selection (Only if admitting) */}
        {isAdmitted && (
          <View style={styles.pickerContainer}>
            <Text style={styles.pickerLabel}>Assign Doctor:</Text>
            <View style={styles.pickerBorder}>
              <Picker
                selectedValue={selectedDoctor}
                onValueChange={(itemValue) => setSelectedDoctor(itemValue)}
              >
                {doctorList.map((doc, index) => (
                  <Picker.Item key={index} label={doc} value={doc} />
                ))}
              </Picker>
            </View>
          </View>
        )}

        <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
          <Text style={styles.saveButtonText}>REGISTER PATIENT</Text>
        </TouchableOpacity>

      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f4f7', padding: 15 },
  formCard: { backgroundColor: '#fff', padding: 20, borderRadius: 10, shadowColor: '#000', elevation: 3 },
  header: { fontSize: 22, fontWeight: 'bold', marginBottom: 20, color: '#333', textAlign: 'center' },
  inputGroup: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#ddd', borderRadius: 8, marginBottom: 15, paddingHorizontal: 10, height: 50 },
  icon: { marginRight: 10, width: 20, textAlign: 'center' },
  input: { flex: 1, fontSize: 16 },
  switchContainer: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20, paddingVertical: 10, borderTopWidth: 1, borderTopColor: '#eee' },
  switchLabel: { fontSize: 16, fontWeight: '600', color: '#333' },
  pickerContainer: { marginBottom: 20 },
  pickerLabel: { fontSize: 14, marginBottom: 5, color: '#555' },
  pickerBorder: { borderWidth: 1, borderColor: '#ddd', borderRadius: 8 },
  saveButton: { backgroundColor: '#28a745', padding: 15, borderRadius: 10, alignItems: 'center' },
  saveButtonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
});

export default AddPatientScreen;