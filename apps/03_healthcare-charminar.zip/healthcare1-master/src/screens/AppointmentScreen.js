// src/screens/AppointmentScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity, Alert, TextInput } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { FontAwesome5 as Icon } from '@expo/vector-icons';
import moment from 'moment';
import { DOCTORS, BUSINESS_RULES } from '../utility/Constant'; 

const AppointmentScreen = ({ appointments = [], addAppointment, patients = [] }) => {
  const [selectedDoctor, setSelectedDoctor] = useState(DOCTORS[0] || ''); 
  const [selectedDate, setSelectedDate] = useState(moment().format('YYYY-MM-DD'));
  const [isBooking, setIsBooking] = useState(false);
  
  const [patientIdForBooking, setPatientIdForBooking] = useState('');
  const [timeSlot, setTimeSlot] = useState('10:00 AM');

  const filteredAppointments = appointments.filter(app => 
    app.doctor === selectedDoctor && app.date === selectedDate
  );

  // --- AUTO-SELECT FIRST PATIENT ---
  useEffect(() => {
    if (isBooking && patients.length > 0) {
        if (!patientIdForBooking) {
            setPatientIdForBooking(patients[0].id);
        }
    }
  }, [isBooking, patients]);

  const handleBookNew = () => {
    if (!patientIdForBooking || !timeSlot) {
        Alert.alert("Missing Info", "Please select a patient and a time slot.");
        return;
    }
    
    const patient = patients.find(p => p.id === patientIdForBooking);
    
    if (!patient) {
        Alert.alert("Error", "Selected patient not found.");
        return;
    }

    const newAppt = {
        date: selectedDate,
        time: timeSlot,
        doctor: selectedDoctor,
        patientName: patient.name,
        phoneNumber: patient.phoneNumber,
    };

    const result = addAppointment(newAppt);

    Alert.alert(result.success ? 'Success' : 'Booking Failed', result.message);
    if (result.success) {
        setIsBooking(false);
        setPatientIdForBooking(''); 
        setTimeSlot('10:00 AM');
    }
  };

  const renderAppointmentItem = ({ item }) => (
    <View style={styles.appointmentCard}>
        <Icon name="user-tag" size={20} color="#007bff" style={{ marginRight: 10 }} />
        <View style={{ flex: 1 }}>
            <Text style={styles.apptTime}>{item.time}</Text>
            <Text style={styles.apptPatient}>{item.patientName} (Ph: {item.phoneNumber})</Text>
        </View>
    </View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Appointments View</Text>

      {/* Filter Section */}
      <View style={styles.filterContainer}>
        <View style={styles.pickerWrapper}>
            <Picker 
              selectedValue={selectedDoctor} 
              onValueChange={(val) => setSelectedDoctor(val)}
              style={styles.picker} 
              mode="dropdown" // FIXED: Helps on Android
            >
                {DOCTORS.map(doc => <Picker.Item key={doc} label={doc} value={doc} />)}
            </Picker>
        </View>
        <TextInput
            style={styles.dateInput}
            placeholder="YYYY-MM-DD"
            value={selectedDate}
            onChangeText={setSelectedDate}
        />
      </View>

      {/* Status Bar */}
      <View style={styles.statusRow}>
        <Text style={styles.statusText}>
            Appointments Today: <Text style={{fontWeight: 'bold'}}>{filteredAppointments.length}/{BUSINESS_RULES.MAX_APPOINTMENTS_PER_DAY}</Text>
        </Text>
        <Icon 
            name={filteredAppointments.length < BUSINESS_RULES.MAX_APPOINTMENTS_PER_DAY ? "check-circle" : "times-circle"} 
            size={24} 
            color={filteredAppointments.length < BUSINESS_RULES.MAX_APPOINTMENTS_PER_DAY ? "#28a745" : "#dc3545"} 
        />
      </View>
      
      <FlatList
        data={filteredAppointments}
        keyExtractor={(item) => item.id}
        renderItem={renderAppointmentItem}
        ListEmptyComponent={() => <Text style={styles.noDataText}>No appointments booked for this doctor on this date.</Text>}
        style={{ flex: 1 }}
      />

      <TouchableOpacity style={styles.bookButton} onPress={() => setIsBooking(!isBooking)}>
        <Icon name={isBooking ? "minus" : "plus"} size={20} color="white" />
        <Text style={styles.bookButtonText}>{isBooking ? 'Hide Booking Form' : 'Book New Appointment'}</Text>
      </TouchableOpacity>

      {/* BOOKING FORM */}
      {isBooking && (
        <View style={styles.bookingForm}>
            <Text style={styles.bookingHeader}>Book for {selectedDoctor} on {selectedDate}</Text>
            
            <Text style={styles.pickerLabel}>Select Patient:</Text>
            
            {/* PATIENT PICKER */}
            <View style={styles.pickerBorder}>
                <Picker 
                    selectedValue={patientIdForBooking} 
                    onValueChange={(itemValue) => setPatientIdForBooking(itemValue)}
                    style={styles.picker} 
                    mode="dropdown" // FIXED
                >
                    {patients.map(p => (
                        <Picker.Item key={p.id} label={`${p.name} (ID: ${p.id})`} value={p.id} />
                    ))}
                </Picker>
            </View>

            <Text style={styles.pickerLabel}>Select Time Slot:</Text>
            
            {/* TIME SLOT PICKER */}
            <View style={styles.pickerBorder}>
                <Picker 
                    selectedValue={timeSlot} 
                    onValueChange={(val) => setTimeSlot(val)}
                    style={styles.picker}
                    mode="dropdown" // FIXED
                >
                    {['10:00 AM', '11:00 AM', '02:00 PM', '03:00 PM', '04:00 PM'].map(time => (
                        <Picker.Item key={time} label={time} value={time} />
                    ))}
                </Picker>
            </View>

            <TouchableOpacity style={styles.confirmButton} onPress={handleBookNew}>
                <Text style={styles.confirmButtonText}>CONFIRM BOOKING</Text>
            </TouchableOpacity>
        </View>
      )}
      <View style={{ height: 20 }} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 15, backgroundColor: '#f0f4f7' },
  header: { fontSize: 22, fontWeight: 'bold', marginBottom: 15, color: '#333' },
  filterContainer: { flexDirection: 'row', marginBottom: 15 },
  
  // Styles for the top filter
  pickerWrapper: { flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 6, backgroundColor: '#fff', marginRight: 10 },
  dateInput: { flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 6, paddingHorizontal: 10, backgroundColor: '#fff', height: 50 },
  
  // Styles for the main booking form pickers
  pickerBorder: { borderWidth: 1, borderColor: '#ccc', borderRadius: 6, backgroundColor: '#fff', marginBottom: 15 },
  picker: { height: 50, width: '100%' },
  
  statusRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', padding: 10, backgroundColor: '#fff', borderRadius: 8, marginBottom: 15 },
  statusText: { fontSize: 16, fontWeight: '600' },
  appointmentCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', padding: 15, borderRadius: 8, marginVertical: 5, borderLeftWidth: 4, borderLeftColor: '#ffc107' },
  apptTime: { fontSize: 16, fontWeight: 'bold', color: '#333' },
  apptPatient: { fontSize: 14, color: '#555' },
  noDataText: { textAlign: 'center', marginTop: 20, fontSize: 16, color: '#888' },
  bookButton: { backgroundColor: '#007bff', padding: 15, borderRadius: 10, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 15 },
  bookButtonText: { color: 'white', fontSize: 16, fontWeight: 'bold', marginLeft: 10 },
  bookingForm: { backgroundColor: '#fff', padding: 15, borderRadius: 10, marginTop: 10, borderWidth: 1, borderColor: '#007bff' },
  bookingHeader: { fontSize: 16, fontWeight: 'bold', marginBottom: 10, color: '#007bff' },
  pickerLabel: { fontSize: 14, fontWeight: '600', marginTop: 5, marginBottom: 5 },
  confirmButton: { backgroundColor: '#28a745', padding: 12, borderRadius: 8, marginTop: 10, alignItems: 'center' },
  confirmButtonText: { color: 'white', fontWeight: 'bold' },
});

export default AppointmentScreen;