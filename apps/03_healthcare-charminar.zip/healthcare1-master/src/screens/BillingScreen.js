// src/screens/BillingScreen.js
import React, { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import { Picker } from '@react-native-picker/picker';
import { FontAwesome5 as Icon } from '@expo/vector-icons'; // FIXED: Expo Icon
import { BUSINESS_RULES } from '../utility/Constant'; // FIXED: Singular Constant
import moment from 'moment'; 

const calculateBill = (patient) => {
  if (!patient.admittedDate) {
    return { breakdown: [], total: 0 };
  }
  
  const admitted = moment(patient.admittedDate);
  const discharged = patient.dischargedDate ? moment(patient.dischargedDate) : moment();
  const daysAdmitted = discharged.diff(admitted, 'days') + 1;

  const roomCost = daysAdmitted * BUSINESS_RULES.DAILY_ROOM_CHARGE;
  const totalMeals = daysAdmitted * BUSINESS_RULES.MEALS_PER_DAY;
  const mealCost = totalMeals * BUSINESS_RULES.MEAL_COST_PER_MEAL;
  const doctorFees = patient.doctorVisits * BUSINESS_RULES.DOCTOR_CHARGE_PER_VISIT;
  const testsTotal = patient.tests.reduce((sum, test) => sum + test.cost, 0);

  const totalBill = roomCost + mealCost + doctorFees + testsTotal;

  const breakdown = [
    { label: 'Days Admitted', value: daysAdmitted, unit: 'days', details: `${daysAdmitted} days` },
    { label: 'Room Charge', value: roomCost, details: `₹${BUSINESS_RULES.DAILY_ROOM_CHARGE} x ${daysAdmitted} days` },
    { label: 'Meal Cost', value: mealCost, details: `₹${BUSINESS_RULES.MEAL_COST_PER_MEAL} x ${totalMeals} meals` },
    { label: 'Doctor Charges', value: doctorFees, details: `₹${BUSINESS_RULES.DOCTOR_CHARGE_PER_VISIT} x ${patient.doctorVisits} visits` },
    { label: 'Medical Tests', value: testsTotal, details: patient.tests.map(t => t.name).join(', ') },
  ];

  return { breakdown, total: totalBill };
};

const BillingScreen = ({ patients }) => {
  const [selectedPatientId, setSelectedPatientId] = useState(patients[0]?.id || null);
  const selectedPatient = patients.find(p => p.id === selectedPatientId);
  const billResult = selectedPatient ? calculateBill(selectedPatient) : { breakdown: [], total: 0 };
  const [showQR, setShowQR] = useState(false);

  return (
    <ScrollView style={styles.container}>
      <Text style={styles.header}>Select Patient for Billing</Text>
      
      <View style={styles.pickerContainer}>
        <Picker
          selectedValue={selectedPatientId}
          onValueChange={(itemValue) => {
             setSelectedPatientId(itemValue);
             setShowQR(false);
          }}
          style={styles.picker}
        >
          {patients.map(p => (
            <Picker.Item key={p.id} label={`${p.name} (ID: ${p.id})`} value={p.id} />
          ))}
        </Picker>
      </View>

      {selectedPatient && selectedPatient.admittedDate ? (
        <View style={styles.billCard}>
          <Text style={styles.billHeader}>Invoice for {selectedPatient.name}</Text>
          <Text style={styles.subHeader}>Admission: {selectedPatient.admittedDate} to {selectedPatient.dischargedDate || 'Present'}</Text>
          
          {billResult.breakdown.filter(b => b.value > 0).map((item, index) => (
            <View key={index} style={styles.breakdownRow}>
              <View style={styles.breakdownLeft}>
                <Text style={styles.breakdownLabel}>{item.label}</Text>
                <Text style={styles.breakdownDetail}>{item.details}</Text>
              </View>
              <Text style={styles.breakdownAmount}>₹ {item.value.toLocaleString()}</Text>
            </View>
          ))}
          
          <View style={styles.separator} />
          
          <View style={styles.totalRow}>
            <Text style={styles.totalLabel}>GRAND TOTAL</Text>
            <Text style={styles.totalAmount}>₹ {billResult.total.toLocaleString()}</Text>
          </View>

          <TouchableOpacity style={styles.paymentButton} onPress={() => setShowQR(!showQR)}>
            <Icon name="qrcode" size={20} color="#fff" />
            <Text style={styles.paymentButtonText}>{showQR ? 'Hide QR Code' : 'Proceed to Online Transaction'}</Text>
          </TouchableOpacity>

          {showQR && (
            <View style={styles.qrContainer}>
              {/* FIXED: Removed the [attachment] text that was here */}
              <Image 
                source={{ uri: 'https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=HospitalPayment' }} 
                style={styles.qrImage} 
              />
              <Text style={styles.qrText}>Scan this UPI QR Code to pay ₹ {billResult.total.toLocaleString()}</Text>
            </View>
          )}

        </View>
      ) : (
        <Text style={styles.noDataText}>Patient not admitted or details incomplete.</Text>
      )}
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f4f7', padding: 15 },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 15, color: '#333' },
  pickerContainer: { borderWidth: 1, borderColor: '#ccc', borderRadius: 8, backgroundColor: '#fff', marginBottom: 20 },
  picker: { height: 50 },
  billCard: { backgroundColor: '#fff', padding: 20, borderRadius: 10, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 5, elevation: 3 },
  billHeader: { fontSize: 22, fontWeight: 'bold', marginBottom: 5, color: '#007bff' },
  subHeader: { fontSize: 16, marginBottom: 15, color: '#555' },
  breakdownRow: { flexDirection: 'row', justifyContent: 'space-between', marginVertical: 5 },
  breakdownLeft: { flex: 1 },
  breakdownLabel: { fontWeight: '600', color: '#333' },
  breakdownDetail: { fontSize: 12, color: '#888' },
  breakdownAmount: { fontWeight: 'bold', color: '#333' },
  separator: { height: 1, backgroundColor: '#eee', marginVertical: 10 },
  totalRow: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 10 },
  totalLabel: { fontSize: 18, fontWeight: 'bold', color: '#dc3545' },
  totalAmount: { fontSize: 22, fontWeight: 'bold', color: '#dc3545' },
  paymentButton: { backgroundColor: '#28a745', padding: 15, borderRadius: 10, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 20 },
  paymentButtonText: { color: 'white', fontSize: 16, fontWeight: 'bold', marginLeft: 10 },
  qrContainer: { alignItems: 'center', marginTop: 20, padding: 20, borderWidth: 1, borderColor: '#ddd', borderRadius: 10 },
  qrImage: { width: 150, height: 150, marginBottom: 10 },
  qrText: { textAlign: 'center', color: '#333', fontWeight: 'bold' },
  noDataText: { fontSize: 18, textAlign: 'center', marginTop: 50, color: '#888' },
});

export default BillingScreen;