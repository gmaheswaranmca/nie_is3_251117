import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { FontAwesome as Icon } from '@expo/vector-icons'; // FIXED

const LoginScreen = ({ onLogin }) => {
  const [username, setUsername] = useState('reception');
  const [password, setPassword] = useState('demo');

  const handleLogin = () => {
    if (username.length > 0 && password.length > 0) {
      onLogin(username); 
    } else {
      Alert.alert("Login Failed", "Please enter valid credentials.");
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.header}>Hospital Login 🏥</Text>
      
      <View style={styles.inputContainer}>
        <Icon name="user" size={20} color="#333" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Username"
          value={username}
          onChangeText={setUsername}
          autoCapitalize="none"
        />
      </View>

      <View style={styles.inputContainer}>
        <Icon name="lock" size={20} color="#333" style={styles.icon} />
        <TextInput
          style={styles.input}
          placeholder="Password"
          secureTextEntry
          value={password}
          onChangeText={setPassword}
        />
      </View>

      <TouchableOpacity style={styles.button} onPress={handleLogin}>
        <Text style={styles.buttonText}>LOGIN</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 30, backgroundColor: '#f0f4f7' },
  header: { fontSize: 32, fontWeight: 'bold', marginBottom: 40, color: '#0056b3' },
  inputContainer: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: 10, marginBottom: 20, paddingHorizontal: 15, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 5, elevation: 3 },
  icon: { marginRight: 10 },
  input: { flex: 1, paddingVertical: 15, fontSize: 16 },
  button: { backgroundColor: '#007bff', borderRadius: 10, paddingVertical: 15, paddingHorizontal: 40, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 5, elevation: 5, marginTop: 20 },
  buttonText: { color: '#fff', fontSize: 18, fontWeight: 'bold' },
});

export default LoginScreen;