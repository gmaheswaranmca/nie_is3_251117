// src/screens/PatientDetailScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TextInput, TouchableOpacity, Alert } from 'react-native';
import { FontAwesome5 as Icon } from '@expo/vector-icons';

const PatientDetailScreen = ({ route, navigation, updatePatient, allTests, patients }) => {
  const { patientId } = route.params;

  // Find the patient from the latest list passed from App.js
  const patientData = patients.find(p => p.id === patientId) || {};

  const [isEditing, setIsEditing] = useState(false);
  const [editableDetails, setEditableDetails] = useState(patientData);

  useEffect(() => {
    setEditableDetails(patientData);
  }, [patientData]);

  const handleSave = () => {
    const finalDetails = { ...editableDetails };

    // 1. Logic for Medications: Convert String -> Array
    if (typeof finalDetails.medications === 'string') {
        finalDetails.medications = finalDetails.medications
            .split(',')
            .map(m => m.trim())
            .filter(m => m !== '');
    }

    // 2. NEW Logic for Tests: Convert String -> Array of Objects {name, cost}
    if (typeof finalDetails.tests === 'string') {
        const testNames = finalDetails.tests
            .split(',')
            .map(t => t.trim())
            .filter(t => t !== '');
        
        // Reconstruct test objects and lookup cost
        finalDetails.tests = testNames.map(name => {
            // Try to find cost in the allTests constant, default to 0 if not found
            const cost = allTests && allTests[name] ? allTests[name] : 0;
            return { name, cost };
        });
    }

    updatePatient(finalDetails); 
    setIsEditing(false);
    Alert.alert('Success', 'Patient details updated!');
  };

  const handleChange = (field, value) => {
    setEditableDetails(prev => ({ ...prev, [field]: value }));
  };

  // --- Custom Component for Rows ---
  const DetailRow = ({ label, value, fieldKey, isEditable, multiline = false }) => {
    // Handle display: If it's an array (like meds), show as comma-separated string
    let displayVal = value;
    
    // Special handling for Tests (Array of Objects) vs Medications (Array of Strings)
    if (Array.isArray(value)) {
        if (value.length > 0 && typeof value[0] === 'object') {
             // It's the Tests array -> map to names
             displayVal = value.map(t => t.name).join(', ');
        } else {
             // It's the Medications array -> just join
             displayVal = value.join(', ');
        }
    }
    
    displayVal = String(displayVal || '');

    return (
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>{label}:</Text>
          
          {isEditing && isEditable ? (
            <View style={styles.inputWrapper}>
              <TextInput
                style={[styles.editableInput, multiline && { height: 60 }]}
                value={displayVal}
                onChangeText={(text) => handleChange(fieldKey, text)}
                multiline={multiline}
                placeholder={`Enter ${label}`}
              />
              {displayVal.length > 0 && (
                  <TouchableOpacity onPress={() => handleChange(fieldKey, '')} style={styles.clearBtn}>
                    <Icon name="times-circle" size={18} color="#dc3545" />
                  </TouchableOpacity>
              )}
            </View>
          ) : (
            <Text style={styles.detailValue}>{displayVal || 'N/A'}</Text>
          )}
        </View>
    );
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.actionBar}>
        <TouchableOpacity style={styles.editButton} onPress={() => setIsEditing(!isEditing)}>
          <Icon name={isEditing ? "times" : "edit"} size={16} color="#fff" />
          <Text style={styles.editButtonText}>{isEditing ? "Cancel" : "Edit Details"}</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionHeader}>Personal Information</Text>
        <DetailRow label="Name" value={editableDetails.name} fieldKey="name" isEditable={true} />
        <DetailRow label="Age" value={editableDetails.age} fieldKey="age" isEditable={true} />
        <DetailRow label="Phone" value={editableDetails.phoneNumber} fieldKey="phoneNumber" isEditable={true} />
        <DetailRow label="Disease" value={editableDetails.disease} fieldKey="disease" isEditable={true} />
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionHeader}>Medical History</Text>
        <DetailRow label="Admitted" value={editableDetails.admittedDate} fieldKey="admittedDate" isEditable={true} />
        <DetailRow label="Discharged" value={editableDetails.dischargedDate} fieldKey="dischargedDate" isEditable={true} />
        
        {/* UPDATED: Doctor is now editable */}
        <DetailRow label="Doctor" value={editableDetails.handlingDoctor} fieldKey="handlingDoctor" isEditable={true} />

        {/* UPDATED: Tests are now editable via DetailRow */}
        <DetailRow 
            label="Tests" 
            value={editableDetails.tests} 
            fieldKey="tests" 
            isEditable={true} 
            multiline={true} 
        />

        <DetailRow
            label="Meds"
            value={editableDetails.medications}
            fieldKey="medications"
            isEditable={true}
            multiline={true}
        />
      </View>

      {isEditing && (
        <TouchableOpacity style={styles.saveButton} onPress={handleSave}>
          <Icon name="save" size={20} color="#fff" />
          <Text style={styles.saveButtonText}>SAVE CHANGES</Text>
        </TouchableOpacity>
      )}

      <View style={{height: 30}} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f4f7', padding: 15 },
  actionBar: { flexDirection: 'row', justifyContent: 'flex-end', marginBottom: 10 },
  editButton: { backgroundColor: '#007bff', padding: 10, borderRadius: 5, flexDirection: 'row', alignItems: 'center' },
  editButtonText: { color: '#fff', marginLeft: 5, fontWeight: 'bold' },
  section: { backgroundColor: '#fff', padding: 15, borderRadius: 10, marginBottom: 15, shadowColor: '#000', elevation: 2 },
  sectionHeader: { fontSize: 18, fontWeight: 'bold', marginBottom: 10, color: '#333', borderBottomWidth: 1, borderBottomColor: '#eee', paddingBottom: 5 },
  detailRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 8, minHeight: 30 },
  detailLabel: { width: 100, fontWeight: '600', color: '#555' },
  detailValue: { flex: 1, fontSize: 16, color: '#333' },
  inputWrapper: { flex: 1, flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#ccc', borderRadius: 5, backgroundColor: '#fafafa', paddingHorizontal: 5 },
  editableInput: { flex: 1, padding: 8, color: '#333', fontSize: 16 },
  clearBtn: { padding: 8 },
  saveButton: { backgroundColor: '#28a745', padding: 15, borderRadius: 10, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginTop: 10 },
  saveButtonText: { color: 'white', fontSize: 16, fontWeight: 'bold', marginLeft: 10 },
});

export default PatientDetailScreen;