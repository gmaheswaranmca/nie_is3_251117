 import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { FontAwesome5 as Icon } from '@expo/vector-icons'; // FIXED

const HomeButton = ({ icon, text, color, onPress }) => (
  <View style={styles.buttonWrapper}>
    <TouchableOpacity style={[styles.circularButton, { backgroundColor: color }]} onPress={onPress}>
      <Icon name={icon} size={40} color="#fff" />
    </TouchableOpacity>
    <Text style={styles.buttonText}>{text}</Text>
  </View>
);

const ReceptionistHome = ({ navigation, onLogout, receptionistName }) => {
  const navigateTo = (screen) => navigation.navigate(screen);

  return ( 
    <View style={styles.container}>
      <View style={styles.topBar}>
        <TouchableOpacity 
          style={styles.profileButton} 
          onPress={() => Alert.alert('User Details', `Receptionist: ${receptionistName}\nRole: Administrator`)}
        >
          <Icon name="user-circle" size={30} color="#333" />
          <Text style={styles.profileText}>{receptionistName}</Text>
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.logoutButton} onPress={onLogout}>
          <Text style={styles.logoutText}>Logout</Text>
          <Icon name="sign-out-alt" size={20} color="#dc3545" style={{ marginLeft: 5 }} />
        </TouchableOpacity>
      </View>
      
      <Text style={styles.header}>Welcome, {receptionistName}!</Text>

      <View style={styles.grid}>
        <HomeButton icon="list-ul" text="View Patients" color="#007bff" onPress={() => navigateTo('ViewPatients')} />
        <HomeButton icon="user-plus" text="Add Patient" color="#28a745" onPress={() => navigateTo('AddPatient')} />
        <HomeButton icon="calendar-check" text="Appointments" color="#ffc107" onPress={() => navigateTo('Appointments')} />
        <HomeButton icon="file-invoice-dollar" text="Billing" color="#dc3545" onPress={() => navigateTo('Billing')} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f0f4f7', padding: 20, paddingTop: 40 },
  topBar: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 20 },
  profileButton: { flexDirection: 'row', alignItems: 'center' },
  profileText: { fontSize: 16, marginLeft: 8, color: '#333', fontWeight: 'bold' },
  logoutButton: { flexDirection: 'row', alignItems: 'center', padding: 8, borderRadius: 8, backgroundColor: '#ffe6e6' },
  logoutText: { color: '#dc3545', fontSize: 16, fontWeight: '600' },
  header: { fontSize: 24, fontWeight: 'bold', marginBottom: 30, color: '#333' },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-around' },
  buttonWrapper: { width: '45%', alignItems: 'center', marginVertical: 15 },
  circularButton: { width: 100, height: 100, borderRadius: 50, justifyContent: 'center', alignItems: 'center', marginBottom: 10, shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 5, elevation: 5 },
  buttonText: { fontSize: 15, fontWeight: '600', textAlign: 'center', color: '#333' },
});

export default ReceptionistHome;