// src/screens/ViewPatientScreen.js
import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet, TextInput, TouchableOpacity } from 'react-native';
// FIXED: Added the missing Icon import
import { FontAwesome5 as Icon } from '@expo/vector-icons'; 

const ViewPatientsScreen = ({ patients, navigation }) => {
  const [searchText, setSearchText] = useState('');

  // Safety check: if patients data is missing, use an empty array []
  const safePatients = patients || [];

  const filteredPatients = safePatients.filter(patient =>
    patient.name.toLowerCase().includes(searchText.toLowerCase())
  );

  const renderPatientCard = ({ item }) => (
    <TouchableOpacity 
      style={styles.card}
      onPress={() => navigation.navigate('PatientDetail', { patientId: item.id })}
    >
      <View>
        <Text style={styles.cardHeader}>👤 {item.name}</Text>
        <Text style={styles.cardDetail}>Age: {item.age}</Text>
        <Text style={styles.cardDetail}>Disease: {item.disease}</Text>
      </View>
      <Icon name="chevron-right" size={20} color="#007bff" />
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.searchContainer}>
        <Icon name="search" size={20} color="#555" style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Search patient name..."
          value={searchText}
          onChangeText={setSearchText}
        />
      </View>
      <FlatList
        data={filteredPatients}
        keyExtractor={(item) => item.id}
        renderItem={renderPatientCard}
        ListEmptyComponent={<Text style={styles.emptyText}>No patients found.</Text>}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff', padding: 10 },
  searchContainer: { flexDirection: 'row', alignItems: 'center', borderWidth: 1, borderColor: '#ccc', borderRadius: 8, margin: 10, paddingHorizontal: 10, backgroundColor: '#f9f9f9' },
  searchIcon: { marginRight: 10 },
  searchInput: { flex: 1, height: 40, fontSize: 16 },
  card: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: '#fff', padding: 15, marginVertical: 5, marginHorizontal: 10, borderRadius: 10, shadowColor: '#000', shadowOpacity: 0.1, shadowRadius: 4, elevation: 3, borderLeftWidth: 5, borderLeftColor: '#007bff' },
  cardHeader: { fontSize: 18, fontWeight: 'bold', color: '#333' },
  cardDetail: { fontSize: 14, color: '#666', marginTop: 2 },
  emptyText: { textAlign: 'center', marginTop: 20, color: '#888', fontSize: 16 },
});

export default ViewPatientsScreen;