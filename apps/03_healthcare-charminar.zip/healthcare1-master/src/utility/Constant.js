// src/utility/Constants.js
export const DOCTORS = ['Dr. A. Sharma', 'Dr. S. Verma', 'Dr. P. Kaur', 'Dr. V. Rao'];

export const BUSINESS_RULES = {
  MEAL_COST_PER_MEAL: 75,
  MEALS_PER_DAY: 3,
  DOCTOR_CHARGE_PER_VISIT: 250,
  DAILY_ROOM_CHARGE: 1000,
  MAX_APPOINTMENTS_PER_DAY: 50,
};

export const TEST_COSTS = {
  bloodTest: 300,
  sugarTest: 200,
  scanning: 1500,
  xray: 800,
  urineTest: 150,
};

// --- Mock Initial Data ---
export const initialPatients = [
  {
    id: '1',
    name: 'Ravi Kumar',
    age: 55,
    disease: 'Fever',
    phoneNumber: '9900123456',
    admittedDate: '2025-11-15',
    dischargedDate: null, // Still admitted
    handlingDoctor: 'Dr. A. Sharma',
    tests: [{ name: 'bloodTest', cost: 300 }],
    medications: ['Crocin'],
    doctorVisits: 2,
  },
  {
    id: '2',
    name: 'Suman Devi',
    age: 28,
    disease: 'Migraine',
    phoneNumber: '9876543210',
    admittedDate: null,
    dischargedDate: null,
    handlingDoctor: null,
    tests: [],
    medications: [],
    doctorVisits: 0,
  },
];

// src/utility/Constant.js

// ... (keep your DOCTORS, BUSINESS_RULES, TEST_COSTS, and initialPatients as they are)

// ADD THIS MISSING SECTION AT THE BOTTOM:
export const initialAppointments = [
  {
    id: '101',
    date: '2025-11-22',
    time: '10:00 AM',
    doctor: 'Dr. A. Sharma',
    patientName: 'Ravi Kumar',
    phoneNumber: '9900123456',
  },
  {
    id: '102',
    date: '2025-11-22',
    time: '11:00 AM',
    doctor: 'Dr. S. Verma',
    patientName: 'Anita Roy',
    phoneNumber: '9876543210',
  },
];