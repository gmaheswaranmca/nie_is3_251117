# FinancialTracker_Trinity
Android app called AzurePay . This is used to manage multiple bank accounts for a user.
