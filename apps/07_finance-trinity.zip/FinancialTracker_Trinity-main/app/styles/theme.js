// app/styles/theme.js
export const colors = {
  bg: "#FFFFFF",
  softBg: "#F6F6FB",
  purpleLight: "#EDE7FF",
  purpleStart: "#6B4EFF",
  purpleEnd: "#6B4EFF",
  primary: "#6B4EFF", // main purple
  accent: "#6B4EFF",
  green: "#10B981",
  danger: "#EF4444",
  text: "#0F172A",
  muted: "#6B7280",
  card: "#FFFFFF"
};

export const layout = {
  radius: 16,
  padding: 20
};
