const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// 🔥 PASTE YOUR KEYS HERE
const API_KEY = "LhdCcdNMD9o3LswA2pGu1AmfBEcNJjC5";  
const API_SECRET = "UG7uk0n0EejN7GLQ";  

// Get Amadeus authentication token
async function getAccessToken() {
  const url = "https://test.api.amadeus.com/v1/security/oauth2/token";

  const params = new URLSearchParams();
  params.append("grant_type", "client_credentials");
  params.append("client_id", API_KEY);
  params.append("client_secret", API_SECRET);

  const response = await axios.post(url, params, {
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
  });
  return response.data.access_token;
}

// 🔥 Create real flight search API
app.get("/flights", async (req, res) => {
  const { from, to, date } = req.query;

  if (!from || !to || !date) {
    return res.status(400).json({ error: "Missing parameters" });
  }

  try {
    const token = await getAccessToken();

    const url = "https://test.api.amadeus.com/v2/shopping/flight-offers";

    const response = await axios.get(url, {
      params: {
        originLocationCode: from,
        destinationLocationCode: to,
        departureDate: date,
        adults: 1,
      },
      headers: { Authorization: `Bearer ${token}` },
    });

    res.json({ flights: response.data.data });
  } catch (error) {
    console.log("BACKEND ERROR:", error.response?.data || error);
    res.status(500).json({ error: "API fetch failed" });
  }
});

app.get("/", (req, res) => res.send("Flight API is running"));

app.listen(4000, "0.0.0.0", () =>
  console.log("🚀 Server running on http://0.0.0.0:4000")
);

