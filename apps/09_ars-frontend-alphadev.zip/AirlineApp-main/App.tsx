import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import LoginScreen from './src/screens/LoginScreen';
import HomeScreen from './src/screens/HomeScreen';
import ProfileScreen from './src/screens/ProfileScreen';
import SearchFlightsScreen from './src/screens/SearchFlightsScreen';
import MyBookingsScreen from './src/screens/MyBookingsScreen';
import OffersScreen from './src/screens/OffersScreen';
import BookingScreen from './src/screens/BookingScreen';
import EditProfileScreen from './src/screens/EditProfileScreen';

// Newly Added Screens
import PassengerDetailsScreen from './src/screens/PassengerDetailsScreen';
import BookingDetailsScreen from './src/screens/BookingDetailsScreen';

// Booking Provider
import { BookingProvider } from './src/context/BookingContext';

// ⭐ THEME PROVIDER
import { ThemeProvider } from './src/context/ThemeContext';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <ThemeProvider>
      <BookingProvider>
        <NavigationContainer>
          <Stack.Navigator
            initialRouteName="Login"
            screenOptions={{ headerShown: false }}
          >
            <Stack.Screen name="Login" component={LoginScreen} />
            <Stack.Screen name="Home" component={HomeScreen} />
            <Stack.Screen name="Profile" component={ProfileScreen} />
            <Stack.Screen name="EditProfile" component={EditProfileScreen} />
            <Stack.Screen name="SearchFlights" component={SearchFlightsScreen} />
            <Stack.Screen name="PassengerDetails" component={PassengerDetailsScreen} />
            <Stack.Screen name="BookingDetails" component={BookingDetailsScreen} />
            <Stack.Screen name="MyBookings" component={MyBookingsScreen} />
            <Stack.Screen name="Offers" component={OffersScreen} />
            <Stack.Screen name="Booking" component={BookingScreen} />
          </Stack.Navigator>
        </NavigationContainer>
      </BookingProvider>
    </ThemeProvider>
  );
}
