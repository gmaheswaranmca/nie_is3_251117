import React, { createContext, useContext, useState } from "react";

const BookingContext = createContext<any>(null);

export const BookingProvider = ({ children }: any) => {
  const [bookings, setBookings] = useState([]);

  const addBooking = (flight: any) => {
    setBookings((prev) => [...prev, flight]);
  };

  return (
    <BookingContext.Provider value={{ bookings, addBooking }}>
      {children}
    </BookingContext.Provider>
  );
};

export const useBookings = () => useContext(BookingContext);
