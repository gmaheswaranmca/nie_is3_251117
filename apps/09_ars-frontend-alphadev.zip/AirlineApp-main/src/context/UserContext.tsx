import React, { createContext, useContext, useState } from "react";

const UserContext = createContext<any>(null);

export const UserProvider = ({ children }: any) => {
  const [user, setUser] = useState({
    name: "Sonia",
    email: "sonia@example.com",
    avatar: "https://i.ibb.co/2WG4R7D/user.png",
  });

  const updateUser = (updatedData: any) => {
    setUser({ ...user, ...updatedData });
  };

  return (
    <UserContext.Provider value={{ user, updateUser }}>
      {children}
    </UserContext.Provider>
  );
};

export const useUser = () => useContext(UserContext);
