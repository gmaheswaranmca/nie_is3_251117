import React from "react";
import { View, Text, StyleSheet, Image, TouchableOpacity, ScrollView } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import Icon from "react-native-vector-icons/Ionicons";

export default function BookingDetailsScreen({ route, navigation }: any) {
  const { booking } = route.params;

  return (
    <LinearGradient colors={["#6dd5ed", "#2193b0"]} style={styles.container}>
      
      {/* Back Button */}
      <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
        <Icon name="arrow-back" size={26} color="#fff" />
      </TouchableOpacity>

      <ScrollView style={{ marginTop: 20 }}>
        <View style={styles.card}>
          
          {/* Airline Row */}
          <View style={styles.row}>
            <Image source={{ uri: booking.logo }} style={styles.logo} />
            <Text style={styles.airline}>{booking.airline}</Text>
          </View>

          {/* Route */}
          <Text style={styles.route}>
            {booking.from} → {booking.to}
          </Text>

          {/* Flight Details */}
          <View style={styles.detailBox}>
            <Text style={styles.label}>Flight Number:</Text>
            <Text style={styles.value}>{booking.flightNumber}</Text>

            <Text style={styles.label}>Date:</Text>
            <Text style={styles.value}>{booking.date}</Text>

            <Text style={styles.label}>Departure:</Text>
            <Text style={styles.value}>{booking.departureTime}</Text>

            <Text style={styles.label}>Arrival:</Text>
            <Text style={styles.value}>{booking.arrivalTime}</Text>

            <Text style={styles.label}>Passenger:</Text>
            <Text style={styles.value}>{booking.passenger}</Text>

            <Text style={styles.label}>Seat:</Text>
            <Text style={styles.value}>{booking.seat}</Text>

            <Text style={styles.label}>Total Fare:</Text>
            <Text style={styles.price}>₹{booking.price}</Text>
          </View>

          {/* Button */}
          <TouchableOpacity style={styles.downloadBtn}>
            <Text style={styles.downloadText}>Download Ticket (PDF)</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },

  backButton: { marginTop: 20, width: 40 },

  card: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 15,
    marginTop: 20,
    elevation: 8,
  },

  row: { flexDirection: "row", alignItems: "center" },
  logo: { width: 50, height: 50, marginRight: 10 },
  airline: { fontSize: 22, fontWeight: "700", color: "#333" },

  route: { fontSize: 20, marginTop: 10, color: "#444", fontWeight: "600" },

  detailBox: { marginTop: 20 },
  label: { fontSize: 14, color: "#666", marginTop: 10 },
  value: { fontSize: 16, fontWeight: "600", color: "#333" },

  price: { fontSize: 22, fontWeight: "700", color: "#2193b0", marginTop: 10 },

  downloadBtn: {
    backgroundColor: "#2193b0",
    padding: 12,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 20,
  },
  downloadText: { fontSize: 16, fontWeight: "700", color: "#fff" },
});
