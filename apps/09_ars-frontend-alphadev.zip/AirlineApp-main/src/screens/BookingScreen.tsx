import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import { useRoute, useNavigation } from "@react-navigation/native";
import { useBookings } from "../context/BookingContext";

export default function BookingScreen() {
  const route = useRoute<any>();
  const navigation = useNavigation<any>();
  const { addBooking } = useBookings();

  const { flight, priceINR } = route.params;

  const handleConfirm = () => {
    addBooking({ flight, priceINR });
    alert("Booking Confirmed!");
    navigation.navigate("MyBookings");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Flight Summary</Text>

      <Text style={styles.text}>Airline: {flight.validatingAirlineCodes[0]}</Text>
      <Text style={styles.text}>
        From: {flight.itineraries[0].segments[0].departure.iataCode}
      </Text>
      <Text style={styles.text}>
        To: {
          flight.itineraries[0].segments[
            flight.itineraries[0].segments.length - 1
          ].arrival.iataCode
        }
      </Text>

      <Text style={styles.text}>Price: ₹{priceINR}</Text>

      <TouchableOpacity style={styles.button} onPress={handleConfirm}>
        <Text style={styles.buttonText}>Confirm Booking</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 30, backgroundColor: "#fff" },
  title: { fontSize: 26, fontWeight: "700", marginBottom: 20 },
  text: { fontSize: 18, marginBottom: 10 },
  button: {
    marginTop: 40,
    backgroundColor: "#2193b0",
    padding: 15,
    borderRadius: 10,
  },
  buttonText: { color: "white", textAlign: "center", fontSize: 18 },
});
