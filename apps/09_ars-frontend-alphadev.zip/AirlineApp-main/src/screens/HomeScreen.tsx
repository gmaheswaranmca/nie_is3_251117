// src/screens/HomeScreen.tsx
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Icon from 'react-native-vector-icons/Ionicons';
import { useThemeContext } from '../context/ThemeContext';

export default function HomeScreen({ navigation }: any) {
  const { colors, theme, toggleTheme } = useThemeContext();

  return (
    <LinearGradient
      colors={
        theme === 'light'
          ? ['#6dd5ed', '#2193b0']
          : ['#1a1a1a', '#000000']
      }
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scroll}>

        {/* Header */}
        <View style={[styles.headerCard, { backgroundColor: colors.card }]}>
          <Text style={[styles.title, { color: colors.text }]}>
            Welcome Back, Sonia ✈️
          </Text>
          <Text style={[styles.subtitle, { color: colors.text }]}>
            Your Airline Dashboard
          </Text>
        </View>

        {/* Action Buttons */}
        <View style={[styles.actionCard, { backgroundColor: colors.card }]}>

          <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('Profile')}>
            <Icon name="person-circle-outline" size={26} color={colors.text} />
            <Text style={[styles.btnText, { color: colors.text }]}>Profile</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('SearchFlights')}>
            <Icon name="airplane-outline" size={26} color={colors.text} />
            <Text style={[styles.btnText, { color: colors.text }]}>Search Flights</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('MyBookings')}>
            <Icon name="receipt-outline" size={26} color={colors.text} />
            <Text style={[styles.btnText, { color: colors.text }]}>My Bookings</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('Offers')}>
            <Icon name="pricetag-outline" size={26} color={colors.text} />
            <Text style={[styles.btnText, { color: colors.text }]}>Offers</Text>
          </TouchableOpacity>

        </View>
      </ScrollView>

      {/* ⭐ Floating Theme Toggle Button (Bottom Right) */}
      <TouchableOpacity
        onPress={toggleTheme}
        style={[
          styles.floatingBtn,
          { backgroundColor: colors.card }
        ]}
      >
        <Icon
          name={theme === 'light' ? 'moon' : 'sunny'}
          size={28}
          color={colors.text}
        />
      </TouchableOpacity>

    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scroll: { padding: 20 },

  headerCard: {
    padding: 20,
    borderRadius: 14,
    marginBottom: 20,
    elevation: 6,
  },

  title: { fontSize: 24, fontWeight: '700', textAlign: 'center', marginBottom: 6 },
  subtitle: { textAlign: 'center' },

  actionCard: {
    padding: 20,
    borderRadius: 14,
    elevation: 6,
  },

  btn: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    marginVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: '#888',
  },

  btnText: {
    fontSize: 17,
    fontWeight: '500',
    marginLeft: 12,
  },

  floatingBtn: {
    position: 'absolute',
    bottom: 25,
    right: 25,
    padding: 15,
    borderRadius: 40,
    elevation: 10,
  },
});
