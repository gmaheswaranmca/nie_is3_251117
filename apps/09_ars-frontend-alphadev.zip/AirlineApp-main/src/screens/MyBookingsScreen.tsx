import React from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  Image,
  TouchableOpacity,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";

export default function MyBookingsScreen({ navigation }: any) {
  // Dummy Bookings Data
  const bookings = [
    {
      id: "1",
      airline: "AI",
      from: "DEL",
      to: "BOM",
      price: "8611",
      date: "2025-01-15",
      logo: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/airindia.png",

      // Extra details for detailed screen
      flightNumber: "AI-401",
      departureTime: "08:30 AM",
      arrivalTime: "10:45 AM",
      passenger: "Shakshi",
      seat: "12A",
    },
  ];

  const renderBooking = ({ item }: any) => (
    <TouchableOpacity
      style={styles.card}
      onPress={() => navigation.navigate("BookingDetails", { booking: item })}
    >
      {/* Airline Logo + Name */}
      <View style={styles.row}>
        <Image source={{ uri: item.logo }} style={styles.logo} />
        <Text style={styles.airline}>{item.airline}</Text>
      </View>

      {/* Route */}
      <Text style={styles.route}>
        {item.from} → {item.to}
      </Text>

      {/* Date */}
      <Text style={styles.date}>{item.date}</Text>

      {/* Price */}
      <Text style={styles.price}>₹{item.price}</Text>
    </TouchableOpacity>
  );

  return (
    <LinearGradient colors={["#6dd5ed", "#2193b0"]} style={styles.container}>
      <Text style={styles.title}>My Bookings</Text>

      <FlatList
        data={bookings}
        keyExtractor={(item) => item.id}
        renderItem={renderBooking}
        contentContainerStyle={{ paddingBottom: 30 }}
      />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },

  title: {
    fontSize: 28,
    fontWeight: "800",
    color: "#fff",
    marginBottom: 20,
  },

  card: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 15,
    marginBottom: 15,
    elevation: 6,
    shadowColor: "#000",
    shadowOpacity: 0.2,
    shadowRadius: 5,
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 5,
  },

  logo: {
    width: 45,
    height: 45,
    marginRight: 10,
  },

  airline: {
    fontSize: 20,
    fontWeight: "700",
    color: "#333",
  },

  route: {
    fontSize: 17,
    marginTop: 7,
    color: "#444",
    fontWeight: "500",
  },

  date: {
    fontSize: 14,
    color: "#777",
    marginTop: 3,
  },

  price: {
    fontSize: 22,
    fontWeight: "700",
    color: "#1976D2",
    marginTop: 10,
  },
});
