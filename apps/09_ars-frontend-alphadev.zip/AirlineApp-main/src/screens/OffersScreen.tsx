// src/screens/OffersScreen.tsx
import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';

export default function OffersScreen() {
  return (
    <LinearGradient colors={['#6dd5ed', '#2193b0']} style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Special Offers ✈️</Text>
        <Text style={styles.offer}>🔥 20% off on all flights!</Text>
        <Text style={styles.offer}>💺 Free seat selection</Text>
        <Text style={styles.offer}>🎒 Extra baggage at ₹499</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', paddingHorizontal: 20 },

  card: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    padding: 25,
    borderRadius: 16,
    elevation: 8,
  },

  title: {
    textAlign: 'center',
    fontSize: 24,
    fontWeight: '700',
    color: '#333',
    marginBottom: 20,
  },

  offer: {
    fontSize: 16,
    color: '#444',
    marginBottom: 10,
    fontWeight: '500',
  },
});

