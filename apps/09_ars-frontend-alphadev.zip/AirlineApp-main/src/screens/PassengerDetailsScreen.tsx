import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ScrollView,
  Alert,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";

export default function PassengerDetailsScreen({ route, navigation }: any) {
  const { flight } = route.params; // flight details coming from Search page

  const [name, setName] = useState("");
  const [age, setAge] = useState("");
  const [gender, setGender] = useState("");
  const [phone, setPhone] = useState("");

  const handleConfirm = () => {
    if (!name || !age || !gender || !phone) {
      return Alert.alert("Missing Fields", "Please fill all details.");
    }

    const booking = {
      id: Date.now().toString(),
      airline: flight.validatingAirlineCodes[0],
      from: flight.itineraries[0].segments[0].departure.iataCode,
      to: flight.itineraries[0].segments.slice(-1)[0].arrival.iataCode,
      price: flight.price.total,
      date: flight.itineraries[0].segments[0].departure.at,
      passengerName: name,
      passengerAge: age,
      passengerGender: gender,
      phone: phone,
    };

    navigation.navigate("MyBookings", { newBooking: booking });
  };

  return (
    <LinearGradient colors={["#6dd5ed", "#2193b0"]} style={styles.container}>
      <ScrollView>
        <Text style={styles.title}>Passenger Details</Text>

        <TextInput
          style={styles.input}
          placeholder="Full Name"
          value={name}
          onChangeText={setName}
        />

        <TextInput
          style={styles.input}
          placeholder="Age"
          keyboardType="numeric"
          value={age}
          onChangeText={setAge}
        />

        <TextInput
          style={styles.input}
          placeholder="Gender (Male / Female)"
          value={gender}
          onChangeText={setGender}
        />

        <TextInput
          style={styles.input}
          placeholder="Phone Number"
          keyboardType="phone-pad"
          value={phone}
          onChangeText={setPhone}
        />

        <TouchableOpacity style={styles.button} onPress={handleConfirm}>
          <Text style={styles.buttonText}>Confirm Booking</Text>
        </TouchableOpacity>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20 },
  title: {
    fontSize: 26,
    fontWeight: "700",
    color: "#fff",
    marginBottom: 20,
  },
  input: {
    backgroundColor: "#fff",
    borderRadius: 10,
    padding: 12,
    marginBottom: 15,
    fontSize: 16,
  },
  button: {
    backgroundColor: "#0b62a1",
    padding: 15,
    borderRadius: 12,
    marginTop: 10,
  },
  buttonText: {
    textAlign: "center",
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
});
