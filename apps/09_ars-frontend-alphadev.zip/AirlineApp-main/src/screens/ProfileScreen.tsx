import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import LinearGradient from "react-native-linear-gradient";
import Icon from "react-native-vector-icons/Ionicons";

export default function ProfileScreen({ navigation }: any) {
  return (
    <LinearGradient colors={["#6dd5ed", "#2193b0"]} style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>My Profile</Text>

        <View style={styles.row}>
          <Icon name="person-circle-outline" size={50} color="#2193b0" />
          <View style={{ marginLeft: 15 }}>
            <Text style={styles.name}>Shakshi</Text>
            <Text style={styles.email}>shakshi@example.com</Text>
          </View>
        </View>

        <View style={styles.divider} />

        <TouchableOpacity style={styles.option}>
          <Icon name="call-outline" size={22} color="#2193b0" />
          <Text style={styles.optionText}>123-456-7890</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.option}>
          <Icon name="location-outline" size={22} color="#2193b0" />
          <Text style={styles.optionText}>India</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={[styles.option, { marginTop: 20 }]}
          onPress={() => navigation.navigate("Login")}
        >
          <Icon name="log-out-outline" size={22} color="#d9534f" />
          <Text style={[styles.optionText, { color: "#d9534f" }]}>Logout</Text>
        </TouchableOpacity>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, justifyContent: "center" },

  card: {
    backgroundColor: "rgba(255,255,255,0.95)",
    padding: 25,
    borderRadius: 16,
    elevation: 8,
  },

  title: {
    textAlign: "center",
    fontSize: 26,
    fontWeight: "700",
    marginBottom: 25,
    color: "#333",
  },

  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },

  name: { fontSize: 20, fontWeight: "600", color: "#333" },
  email: { fontSize: 14, color: "#666", marginTop: 3 },

  divider: {
    height: 1,
    backgroundColor: "#ccc",
    marginVertical: 20,
  },

  option: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 15,
  },

  optionText: {
    fontSize: 16,
    marginLeft: 12,
    color: "#333",
    fontWeight: "500",
  },
});
