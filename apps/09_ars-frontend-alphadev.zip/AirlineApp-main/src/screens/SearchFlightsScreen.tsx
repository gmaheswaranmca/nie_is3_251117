import React, { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  ActivityIndicator,
  FlatList,
  Image,
} from "react-native";
import LinearGradient from "react-native-linear-gradient";
import Icon from "react-native-vector-icons/Ionicons";
import { useNavigation } from "@react-navigation/native";

// ⭐ Airline Logos
const airlineLogos: any = {
  AI: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/airindia.png",
  UK: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/vistara.png",
  "6E": "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/indigo.png",
  SG: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/spicejet.png",
  G8: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/gofirst.png",
  QP: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/akasa.png",
  EK: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/emirates.png",
  QR: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/qatar.png",
  BA: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/british.png",
  LH: "https://raw.githubusercontent.com/kamleshn12/airline-logos/main/lufthansa.png",
};

// Convert EUR → INR
const convertToINR = (eur: string) => {
  const rate = 90;
  return (parseFloat(eur) * rate).toFixed(0);
};

export default function SearchFlightsScreen() {
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [date, setDate] = useState("");
  const [returnDate, setReturnDate] = useState("");

  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState([]);

  const [nonStopOnly, setNonStopOnly] = useState(false);
  const [sortLow, setSortLow] = useState(false);

  const navigation = useNavigation<any>();

  // ⭐ SEARCH FLIGHTS
  const searchFlights = async () => {
    if (!from || !to || !date) {
      alert("Please fill all fields.");
      return;
    }

    setLoading(true);

    const url = `http://10.62.36.153:4000/flights?from=${from}&to=${to}&date=${date}`;

    try {
      const response = await fetch(url);
      const data = await response.json();

      let flights = data.flights || [];

      if (nonStopOnly) {
        flights = flights.filter(
          (item: any) => item.itineraries?.[0]?.segments?.length === 1
        );
      }

      if (sortLow) {
        flights.sort(
          (a: any, b: any) =>
            parseFloat(a.price.grandTotal) -
            parseFloat(b.price.grandTotal)
        );
      }

      setResults(flights);
    } catch (error) {
      alert("API Error. Something went wrong.");
    } finally {
      setLoading(false);
    }
  };

  // ⭐ RENDER FLIGHT CARD
  const renderFlight = ({ item }: any) => {
    const priceEUR = item.price?.grandTotal;
    const priceINR = convertToINR(priceEUR);

    const airline = item.validatingAirlineCodes?.[0] || "Unknown";
    const logo = airlineLogos[airline];

    const segs = item.itineraries?.[0]?.segments || [];
    const firstSeg = segs[0];
    const lastSeg = segs[segs.length - 1];

    const fromCode = firstSeg?.departure?.iataCode;
    const toCode = lastSeg?.arrival?.iataCode;

    const depTime = firstSeg?.departure?.at;
    const arrTime = lastSeg?.arrival?.at;

    return (
      <View style={styles.flightCard}>
        {/* Airline */}
        <View style={{ flexDirection: "row", alignItems: "center" }}>
          {logo && (
            <Image
              source={{ uri: logo }}
              style={{ width: 40, height: 40, marginRight: 10 }}
              resizeMode="contain"
            />
          )}
          <Text style={styles.airline}>{airline}</Text>
        </View>

        {/* Route */}
        <Text style={styles.route}>{fromCode} → {toCode}</Text>

        {/* Time */}
        <Text style={styles.time}>{depTime} - {arrTime}</Text>

        {/* Price */}
        <Text style={styles.price}>₹{priceINR}</Text>

        {/* ⭐ BOOK BUTTON */}
        <TouchableOpacity
          style={styles.bookButton}
          onPress={() =>
            navigation.navigate("PassengerDetails", {
              flight: item,
              airline,
              logo,
              priceINR,
              fromCode,
              toCode,
              depTime,
              arrTime,
            })
          }
        >
          <Text style={styles.bookText}>Book</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <LinearGradient colors={["#6dd5ed", "#2193b0"]} style={styles.container}>
      <View style={styles.card}>
        <Text style={styles.title}>Search Flights</Text>

        <View style={styles.inputWrap}>
          <Icon name="airplane-outline" size={20} color="#2193b0" />
          <TextInput
            style={styles.input}
            placeholder="From (DEL)"
            value={from}
            onChangeText={setFrom}
          />
        </View>

        <View style={styles.inputWrap}>
          <Icon name="airplane-outline" size={20} color="#2193b0" />
          <TextInput
            style={styles.input}
            placeholder="To (BOM)"
            value={to}
            onChangeText={setTo}
          />
        </View>

        <View style={styles.inputWrap}>
          <Icon name="calendar-outline" size={20} color="#2193b0" />
          <TextInput
            style={styles.input}
            placeholder="Departure YYYY-MM-DD"
            value={date}
            onChangeText={setDate}
          />
        </View>

        {/* Optional Return */}
        <View style={styles.inputWrap}>
          <Icon name="calendar-outline" size={20} color="#2193b0" />
          <TextInput
            style={styles.input}
            placeholder="Return YYYY-MM-DD (optional)"
            value={returnDate}
            onChangeText={setReturnDate}
          />
        </View>

        {/* Buttons */}
        <View style={{ flexDirection: "row", justifyContent: "space-between" }}>
          <TouchableOpacity
            style={styles.smallBtn}
            onPress={() => setSortLow(!sortLow)}
          >
            <Text style={styles.smallText}>
              {sortLow ? "Sorted ✓" : "Sort Price"}
            </Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.smallBtn}
            onPress={() => setNonStopOnly(!nonStopOnly)}
          >
            <Text style={styles.smallText}>
              {nonStopOnly ? "Non-stop ✓" : "Non-stop"}
            </Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.button} onPress={searchFlights}>
          <Text style={styles.buttonText}>Search</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#fff" style={{ marginTop: 20 }} />
      ) : (
        <FlatList
          data={results}
          keyExtractor={(item, index) => index.toString()}
          renderItem={renderFlight}
        />
      )}
    </LinearGradient>
  );
}

// ----------------------- STYLES -----------------------

const styles = StyleSheet.create({
  container: { flex: 1, paddingHorizontal: 20 },

  card: {
    backgroundColor: "rgba(255,255,255,0.95)",
    padding: 25,
    borderRadius: 16,
    elevation: 8,
    marginTop: 40,
    marginBottom: 10,
  },

  title: {
    textAlign: "center",
    fontSize: 24,
    fontWeight: "700",
    marginBottom: 20,
  },

  inputWrap: {
    flexDirection: "row",
    alignItems: "center",
    borderWidth: 1,
    borderColor: "#ddd",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginBottom: 15,
    backgroundColor: "#fff",
  },

  input: { flex: 1, marginLeft: 10 },

  smallBtn: {
    backgroundColor: "#fff",
    padding: 8,
    borderRadius: 8,
    marginBottom: 10,
    width: "48%",
  },

  smallText: { textAlign: "center", color: "#000" },

  button: {
    backgroundColor: "#0b62a1",
    paddingVertical: 13,
    borderRadius: 12,
    marginTop: 10,
  },

  buttonText: {
    color: "#fff",
    textAlign: "center",
    fontSize: 17,
    fontWeight: "700",
  },

  flightCard: {
    backgroundColor: "white",
    padding: 18,
    borderRadius: 12,
    marginTop: 12,
    elevation: 5,
  },

  airline: { fontSize: 18, fontWeight: "700" },
  route: { fontSize: 16, marginTop: 4, color: "#555" },
  time: { fontSize: 14, marginTop: 4, color: "#777" },

  price: {
    fontSize: 20,
    fontWeight: "700",
    marginTop: 8,
    color: "#2193b0",
  },

  bookButton: {
    marginTop: 12,
    backgroundColor: "#2193b0",
    paddingVertical: 10,
    borderRadius: 8,
  },

  bookText: {
    color: "white",
    textAlign: "center",
    fontWeight: "700",
  },
});
