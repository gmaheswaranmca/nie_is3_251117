// App.js
import 'react-native-gesture-handler'; // MUST be the first line
import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import TabNavigator from './navigation/TabNavigator';
import { SafeAreaView, StyleSheet } from 'react-native';

// --- NEW FIX: Use Expo's dedicated registration ---
import { registerRootComponent } from 'expo'; 
// We are not using `export default function App()` anymore

function MainApp() {
  return (
    // SafeAreaView handles notches and status bars
    <SafeAreaView style={styles.container}>
      <NavigationContainer>
        <TabNavigator />
      </NavigationContainer>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
  },
});

// Explicitly register the component as the root of the app
registerRootComponent(MainApp);