import React, { useState } from "react";
import {
  View,
  Text,
  Button,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
} from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createStackNavigator } from "@react-navigation/stack";

const Stack = createStackNavigator();

/* -------------------------------------------------------
                 TRAIN DATA
------------------------------------------------------- */
const TRAINS = [
  {
    id: "1",
    name: "Express 101",
    from: "Delhi",
    to: "Mumbai",
    departure: "10:00 AM",
    arrival: "6:00 PM",
    price: 1200,
  },
  {
    id: "2",
    name: "Shatabdi 202",
    from: "Delhi",
    to: "Mumbai",
    departure: "6:00 AM",
    arrival: "2:00 PM",
    price: 2000,
  },
  {
    id: "3",
    name: "Superfast 303",
    from: "Delhi",
    to: "Kolkata",
    departure: "8:00 AM",
    arrival: "8:00 PM",
    price: 1500,
  },
];

/* -------------------------------------------------------
                 HOME SCREEN
------------------------------------------------------- */
function HomeScreen({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Available Trains</Text>

      <FlatList
        data={TRAINS}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.card}
            onPress={() =>
              navigation.navigate("PassengerDetails", { train: item })
            }
          >
            <Text style={styles.trainName}>{item.name}</Text>
            <Text>
              {item.from} ➝ {item.to}
            </Text>
            <Text>Departure: {item.departure}</Text>
            <Text>Arrival: {item.arrival}</Text>
            <Text style={styles.price}>₹{item.price}</Text>
          </TouchableOpacity>
        )}
      />
    </View>
  );
}

/* -------------------------------------------------------
             PASSENGER DETAILS SCREEN
------------------------------------------------------- */
function PassengerDetailsScreen({ route, navigation }) {
  const { train } = route.params;

  const [name, setName] = useState("");
  const [age, setAge] = useState("");

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>Passenger Details</Text>

      <Text style={styles.subTitle}>Selected Train:</Text>
      <Text style={styles.details}>{train.name}</Text>
      <Text style={styles.details}>
        {train.from} ➝ {train.to}
      </Text>
      <Text style={styles.details}>₹{train.price}</Text>

      <TextInput
        style={styles.input}
        placeholder="Passenger Name"
        value={name}
        onChangeText={setName}
      />

      <TextInput
        style={styles.input}
        placeholder="Age"
        value={age}
        onChangeText={setAge}
        keyboardType="numeric"
      />

      <Button
        title="Confirm Booking"
        onPress={() =>
          navigation.navigate("Ticket", {
            train,
            passenger: { name, age },
          })
        }
      />
    </View>
  );
}

/* -------------------------------------------------------
                   TICKET SCREEN
------------------------------------------------------- */
function TicketScreen({ route }) {
  const { train, passenger } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.heading}>🎟 Ticket Confirmed</Text>

      <Text style={styles.details}>Passenger: {passenger.name}</Text>
      <Text style={styles.details}>Age: {passenger.age}</Text>
      <Text style={styles.details}>Train: {train.name}</Text>
      <Text style={styles.details}>
        Route: {train.from} ➝ {train.to}
      </Text>
      <Text style={styles.details}>Departure: {train.departure}</Text>
      <Text style={styles.details}>Arrival: {train.arrival}</Text>

      <Text style={styles.price}>Paid: ₹{train.price}</Text>

      <Text style={{ marginTop: 20, fontSize: 20 }}>
        Have a safe journey! 🚆
      </Text>
    </View>
  );
}

/* -------------------------------------------------------
                   NAVIGATION SETUP
------------------------------------------------------- */
export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Home">
        <Stack.Screen name="Home" component={HomeScreen} />

        <Stack.Screen
          name="PassengerDetails"
          component={PassengerDetailsScreen}
          options={{ title: "Passenger Details" }}
        />

        <Stack.Screen
          name="Ticket"
          component={TicketScreen}
          options={{ title: "Ticket" }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

/* -------------------------------------------------------
                         STYLES
------------------------------------------------------- */
const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  heading: {
    fontSize: 26,
    fontWeight: "bold",
    marginBottom: 20,
    textAlign: "center",
  },
  card: {
    backgroundColor: "#e8e8e8",
    padding: 15,
    borderRadius: 10,
    marginVertical: 10,
  },
  trainName: {
    fontSize: 18,
    fontWeight: "bold",
  },
  input: {
    borderWidth: 1,
    padding: 12,
    borderRadius: 5,
    marginVertical: 10,
  },
  details: {
    fontSize: 18,
    marginVertical: 4,
  },
  subTitle: {
    fontSize: 20,
    marginTop: 10,
    marginBottom: 5,
    fontWeight: "bold",
  },
  price: {
    fontSize: 18,
    fontWeight: "bold",
    marginTop: 5,
  },
});