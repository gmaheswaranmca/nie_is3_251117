export const colors = {
  primary: '#6750A4',    // Modern Purple
  primaryContainer: '#EADDFF',
  secondary: '#625B71',
  background: '#FFFBFE',
  surface: '#E7E0EC',
  error: '#B3261E',
  white: '#FFFFFF',
  black: '#1C1B1F',
};