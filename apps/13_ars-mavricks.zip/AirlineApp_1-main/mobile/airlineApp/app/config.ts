// Replace HOST_IP with your PC IPv4 address (example: 192.168.0.105)
export const BACKEND_HOST = 'http://10.10.58.22:4000';