export const AIRLINE_NAMES: Record<string, string> = {
  '6E': 'IndiGo',
  'AI': 'Air India',
  'UK': 'Vistara',
  'SG': 'SpiceJet',
  'G8': 'Akasa Air',
  'IX': 'Air India Express',
  '9W': 'Jet Airways',
  'QR': 'Qatar Airways',
  'EK': 'Emirates',
  'AF': 'Air France'
};
